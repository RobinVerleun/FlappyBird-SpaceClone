All programming was done on Ubuntu 15.x

Type make to create an executable for the game.

Run the executable in the terminal with the './' command.

Must have allegro in your path for compiling to work properly. 